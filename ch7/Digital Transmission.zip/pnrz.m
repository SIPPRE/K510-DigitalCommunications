% (pnrz.m)
% generating a rectangular pulse of width T
% Usage function pout=pnrz(T);
function pout=pnrz(T)
pout=ones(1,T);
end